﻿param (
    [string]$resourceGroup = "default",    
    [string]$subscriptionId = "default",
    [string]$location = "centralus",
    [string]$sampleCategory = "None"
)

#Connect-AzAccount

$uniqueName = "xiwuhc8"
$searchServiceKey = "09F09E814999D1632905E1A6A850A273"
$storageAccountKey = "o1pICDWeeJsdq2GsBPt+jfoPLIGY9E0zrKoMxw0jJZ+n2PUgckA/J1XuCf/HJvZM28dACsn4I6Po/Za2Fw5t4A=="

if($sampleCategory -notin "None", "healthcare", "oilandgas", "retail"){
    Write-Error "The -sampleCategory needs to be one of the followings: healthcare, oilandgas, retail"
    Break;
}

$prefix = $uniqueName
if($resourceGroup -eq "default"){
    $resourceGroupName = $uniqueName
} else{
    $resourceGroupName = $resourceGroup
}

if($subscriptionId -ne "default"){
    $context = Get-AzSubscription -SubscriptionId $subscriptionId
    Set-AzContext @context
}

#New-AzResourceGroup -Name $resourceGroupName -Location $location

#$result = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile .\main.json -prefix $prefix


#$azureFunctionKey = "u2VYniHevC4fFcTjKGCNXHvj4Aml8DzD97m5aipXemCqq89/GTRxpg=="

$sampleContentStorageAccountName = "cognitivesearchcontent"
$webUIAppName = $prefix+"-webui"
$webAPIAppName = $prefix + "-webapi"
$searchServiceName = $prefix + "-search"
$storageAccountName = $prefix + "storage"
$storageContainerName = "rawdata"
$facetFiltersStorageContainerName = "facetfilters"
$facetFiltersSourceStorageContainerName = $prefix + "-" + $sampleCategory
$cognitiveServiceName = $prefix + "-cogs"

$headers = @{
'api-key' = $searchServiceKey
'Content-Type' = 'application/json' 
'Accept' = 'application/json' }


$baseSearchUrl = "https://"+$searchServiceName+".search.windows.net"

$url = $baseSearchUrl + "/indexers/demoindexer?api-version=2019-05-06"

Invoke-RestMethod -Uri $url -Headers $headers -Method Delete | ConvertTo-Json
$url = $baseSearchUrl + "/indexes/demoindex?api-version=2019-05-06"

Invoke-RestMethod -Uri $url -Headers $headers -Method Delete | ConvertTo-Json
$url = $baseSearchUrl + "/skillsets/demoskillset?api-version=2019-05-06-preview"

Invoke-RestMethod -Uri $url -Headers $headers -Method Delete | ConvertTo-Json
$url = $baseSearchUrl + "/datasources/demodata?api-version=2019-05-06"

Invoke-RestMethod -Uri $url -Headers $headers -Method Delete | ConvertTo-Json


$dataSourceBody = Get-Content -Path .\base-datasource.json

$dataSourceBody = $dataSourceBody -replace "%%storageAccountName%%", $storageAccountName
$dataSourceBody = $dataSourceBody -replace "%%storageAccountKey%%", $storageAccountKey
$dataSourceBody = $dataSourceBody -replace "%%storageContainerName%%", $storageContainerName


$url = $baseSearchUrl + "/datasources?api-version=2019-05-06"

Invoke-RestMethod -Uri $url -Headers $headers -Method Post -Body $dataSourceBody | ConvertTo-Json

$url = $baseSearchUrl + "/skillsets/demoskillset?api-version=2019-05-06-Preview"

$skillBody = Get-Content -Path .\base-skills.json

$cognitiveServiceKeys = Get-AzCognitiveServicesAccountKey -ResourceGroupName $resourceGroupName -Name $cognitiveServiceName

$skillBody = $skillBody -replace "%%cognitiveServiceKey%%", $cognitiveServiceKeys.Key1
$skillBody = $skillBody -replace "%%azure_webapi_name%%", $webAPIAppName
$skillBody = $skillBody -replace "%%storageAccountName%%", $storageAccountName
$skillBody = $skillBody -replace "%%storageAccountKey%%", $storageAccountKey

Invoke-RestMethod -Uri $url -Headers $headers -Method Put -Body $skillBody | ConvertTo-Json

$url = $baseSearchUrl + "/indexes/demoindex?api-version=2019-05-06"

$indexBody = Get-Content -Path .\base-index.json

Invoke-RestMethod -Uri $url -Headers $headers -Method Put -Body $indexBody | ConvertTo-Json

$url = $baseSearchUrl + "/indexers/demoindexer?api-version=2019-05-06"

$indexerBody = Get-Content -Path .\base-indexer.json

Invoke-RestMethod -Uri $url -Headers $headers -Method Put -Body $indexerBody | ConvertTo-Json

