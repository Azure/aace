﻿Install-Module -Name Az

Install-Module -Name Az.Search