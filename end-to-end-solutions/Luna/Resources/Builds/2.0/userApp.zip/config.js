var Configs = {
    API_ENDPOINT: "https://lunaaitest-apiapp.azurewebsites.net/api/", //"https://lunatest-apiapp.azurewebsites.net/api/", // https://luna-dev-api.azurewebsites.net/api/
    ISV_NAME: "Microsoft",
    AAD_APPID: "b9285d6f-f251-40c0-8123-7aa49ef61d0e", //"9ee174e4-e4ac-4a85-b6e3-85d52ca5f842",
    AAD_ENDPOINT: "https://lunaaitest-isvapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "false",
    ENABLE_V2: "true"
}