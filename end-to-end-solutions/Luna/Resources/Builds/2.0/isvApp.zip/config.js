var Configs = {
    API_ENDPOINT: "https://lunamgmtprod.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "11333002-6e05-4478-b423-c959d2600bc2", 
    AAD_ENDPOINT: "https://lunamgmtisv.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}