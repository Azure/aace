var Configs = {
    API_ENDPOINT: "https://lunatest-apiapp.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "95e7065f-e11a-4770-b0bb-e980e7148e77",
    AAD_ENDPOINT: "https://lunatest-isvapp.azurewebsites.net"
}
