var Configs = {
    API_ENDPOINT: "https://lunatest-apiapp.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "50a6b69d-325a-4c02-aff3-51703d904789",
    AAD_ENDPOINT: "https://lunatest-isvapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#118811",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}