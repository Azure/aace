﻿Install-Module -Name Az -AllowClobber
Install-Module -Name Az.Search -AllowClobber